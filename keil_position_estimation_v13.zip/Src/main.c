/**
  ******************************************************************************
  * File Name          : position_estimation_v13.c
  * Description        : Main program body
  ******************************************************************************

  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */
#include "math.h"
#include <string.h>
#include "ssd1306.h"
#include "fonts.h"
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

I2C_HandleTypeDef hi2c1;
DMA_HandleTypeDef hdma_i2c1_tx;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
uint8_t cnt_blink;
#define pi 3.1415926536
#define dt 0.001
float calib[6],position[3],angle[3];
uint8_t flag_calib=1,mode,flag_mode1=0,flag_mode2=0,flag_mode3=0,flag_mode4=0,flag_mode_select,flag_=0,flag_yaw; 
uint16_t elapsed_time[2];
uint32_t mode_timer=0,motor_cnt=0,cnt_mode3;

// MPU_6050 I2C communication variables
unsigned char buffer[20];
int16_t raw_accX,raw_accY,raw_accZ,raw_tmp,raw_gyrX,raw_gyrY,raw_gyrZ;

// STEP MOTOR DRIVE variables
uint8_t step_phase = 0, flag_motor=0;
unsigned int ms_time=0,ms_motor=0; 

// position calculation, zero update, possiton update variables
uint8_t flag_zero_update[3]={1,1,1}, flag_zero_update_old[3]={1,1,1}, flag_pos_update[3];  
uint16_t	counter_zero_update[3], counter_offset_update[3];
float offset[3],acc_old[3], speed[3],speed_old[3], acu[3], pos_update[3][5];
float acc_rotated[3],acc_tmp[3],acc_magn;

// quaternion variables temps
float quat_1[4]={0.3,0.5,0.2,0.7874007874},quat_2[4],quat_3[4],quat_old[4]={1,0,0,0},quat[4];
float acc_raw[3]={5,1,-3}, acc_rot[3]={0,0,0},direction, position_time;

//kalman variables
float J[12],F[3],step[4];

//OLED
char oled_data[100];


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_ADC1_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void get_mpu_values (void);
void forward(void);
void backward(void);
void left(void);
void right(void);
void calibration(void);															// Initialize starting angle	 
void motor_disable(void);
void calc_pos( float* );														// (Acc_input)
void motor_drive(uint8_t,uint16_t);									// (direction,tork) or (direction,speed^-1)
																										// Direction == 1 forward, Direction == 2 back, Direction == 3 left, Direction == 4 right, 
			
// last poiters is output
void quat2euler(float *);														// Convert the quaternion to euler anlge
void calc_quat(float *,float *,float *,float *);		// Kalman  with quaternion 								(gyro, acc, beta, quat_old,quat) 
void quat_conj(float *,float *);										// Quaternion conjugate    								(q_in,q_out)
void quat_prod(float *, float *, float *);					// Quaternion product			 								(q_1,q_2,q_out)
void quat_rotate(float *, float *,float *);					// Rotate the acc and remove gravity			(v_in,q,v_out)
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_ADC1_Init();

  /* USER CODE BEGIN 2 */
	motor_disable();
	HAL_TIM_Base_Start(&htim2);
	
	ssd1306_Init();
	
	ssd1306_Fill(Black);
	ssd1306_SetCursor(20,2);
	ssd1306_WriteString( "POSITION",Font_11x18,White);
	ssd1306_SetCursor(9,22);
	ssd1306_WriteString( "ESTIMATION",Font_11x18,White);
	ssd1306_SetCursor(36,42);
	ssd1306_WriteString( "ROBOT",Font_11x18,White);
	ssd1306_UpdateScreen();
	
	HAL_Delay(500);
	
	
	buffer[0]=0x6b;														 //Register address to wake up mpu6050
	buffer[1]=0;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);
	
	buffer[0]=0x1C;														 //Register address to configure accelerometer (+-2g max)(16384 = 1g)
	buffer[1]=0;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);

	buffer[0]=0x1a; 														//Configure the digital low pass for Gyr (DLPF_CFG=3)(bandw = 41, delay 5.9 ms)
	buffer[1]=3;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);
	
	buffer[0]=0x1b; 														//Configure the gyro  (+- 500  �/s)(65.5 =�/s)  -  (FCHOICE_B = 0), no gyro filtering
	buffer[1]=8;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);
	
	buffer[0]=0x1d; 														//Configure the digital low pass for Acc (ACCEL_FCHOICE_B=0), no acc filtering
	buffer[1]=0;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);
	
/*
	ssd1306_Fill(Black);
	ssd1306_SetCursor(0,0);
	ssd1306_WriteString( "Calibrating...",Font_7x10,White);
	ssd1306_UpdateScreen();	
*/
	calibration();															// Initialize starting angle	
	
	ssd1306_Fill(Black);
	ssd1306_SetCursor(0,0);
	ssd1306_WriteString( "Press button",Font_7x10,White);
	ssd1306_SetCursor(0,12);
	ssd1306_WriteString( "to select mode",Font_7x10,White);
	ssd1306_UpdateScreen();


	ms_time=HAL_GetTick(); //Initialize the time
	ms_motor=HAL_GetTick(); //Initialize the motor time


	
		
	
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
		
	switch (mode)	{
			case 0 :// Stand by  
				ssd1306_Fill(Black);
				ssd1306_SetCursor(0,0);
				ssd1306_WriteString( "Press button",Font_7x10,White);
				ssd1306_SetCursor(0,12);
				ssd1306_WriteString( "to select mode",Font_7x10,White);
				ssd1306_UpdateScreen();
				break;
			
			case 1 :// Demo 1, calculate movement and return initial position
				if(HAL_GetTick() - mode_timer < 3000){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 1",Font_7x10,White);
					ssd1306_UpdateScreen();
				}
				else if(HAL_GetTick() - mode_timer >= 3000 &&  HAL_GetTick() - mode_timer < 3100){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 1 activated",Font_7x10,White);
					ssd1306_UpdateScreen();
					flag_mode_select=1;
				}
				else{
					if(flag_mode1==0){
						ssd1306_Fill(Black);
						ssd1306_SetCursor(0,0);
						ssd1306_WriteString( "Mode 1 activated",Font_7x10,White);
						ssd1306_SetCursor(14,22);
						ssd1306_WriteString( "MOVE IT !",Font_11x18,White);
						ssd1306_UpdateScreen();
						motor_cnt=0;
						flag_yaw=0;
						flag_calib=0;						
						flag_mode1=1;
					}
					
					if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_5)){
						HAL_Delay(200);
						while(1){	
							if(flag_mode1==1){
								flag_calib=1;
								
								ssd1306_Fill(Black);
								ssd1306_SetCursor(0,0);
								ssd1306_WriteString( "Mode 1 activated",Font_7x10,White);
								
								position_time = sqrt(position[0]*position[0] + position[1]*position[1]  )/0.0002175 ;
								if		 (position[0]>0 && position[1]>0){direction = -180 + atanf(position[1]/position[0])*180/pi;}
								else if(position[0]>0 && position[1]<0){direction =  180 + atanf(position[1]/position[0])*180/pi;}
								else if(position[0]<0 && position[1]<0){direction = atanf(position[1]/position[0])*180/pi;}
								else{direction = atanf(position[1]/position[0])*180/pi ;}
								
								sprintf(oled_data,"posX = %f",position[0]);
								ssd1306_SetCursor(0,24);
								ssd1306_WriteString( oled_data,Font_7x10,White);
								
								sprintf(oled_data,"posY = %f",position[1]);
								ssd1306_SetCursor(0,36);
								ssd1306_WriteString( oled_data,Font_7x10,White);
								
								sprintf(oled_data,"direc = %f",direction);
								ssd1306_SetCursor(0,48);
								ssd1306_WriteString( oled_data,Font_7x10,White);
								
								ssd1306_UpdateScreen();
								
								HAL_Delay(3000);
								
								flag_yaw=1;
								flag_calib=0;
								flag_mode1=2;
								
								while(angle[2] < direction-1) {motor_drive(3,12);}
								while(angle[2] > direction+1) {motor_drive(4,12);}
							
								HAL_Delay(1000);
								flag_yaw=0;
							}

							while(HAL_GetTick() - ms_time >=1){ms_time=HAL_GetTick(); motor_cnt++;}
							if(motor_cnt<position_time){motor_drive(1,6);}
							else if(motor_cnt>=position_time){
								HAL_Delay(1000);
								flag_yaw=1;
								while(angle[2] < -1) {motor_drive(3,12);}
								while(angle[2] > +1) {motor_drive(4,12);}
								motor_disable();
								HAL_Delay(200);

																
								ssd1306_Fill(Black);
								ssd1306_SetCursor(25,2);
								ssd1306_WriteString( "ARRIVED",Font_11x18,White);
								ssd1306_SetCursor(9,22);
								ssd1306_WriteString( "TO INITIAL",Font_11x18,White);
								ssd1306_SetCursor(20,42);
								ssd1306_WriteString( "POSITION",Font_11x18,White);
								ssd1306_UpdateScreen();
							}
						}
					}
				}
				break;
			
			case 2 :	// Demo 2, Drive motors 4 second and show position on screen
				if(HAL_GetTick() - mode_timer < 3000){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 2",Font_7x10,White);
					ssd1306_UpdateScreen();
				}
				else if(HAL_GetTick() - mode_timer >= 3000 &&  HAL_GetTick() - mode_timer < 3100){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 2 activated",Font_7x10,White);
					ssd1306_UpdateScreen();
				}
				else{
					if(flag_mode2==0){
						ssd1306_Fill(Black);
						ssd1306_SetCursor(0,0);
						ssd1306_WriteString( "Mode 2 activated",Font_7x10,White);
						ssd1306_SetCursor(0,24);
						ssd1306_WriteString( "Motors are running",Font_7x10,White);
						ssd1306_UpdateScreen();
						motor_cnt=0;
						flag_calib=0;
						flag_mode2=1;
					}
					while(HAL_GetTick() - ms_time >=1){ms_time=HAL_GetTick(); motor_cnt++;}
					if(motor_cnt<4000){motor_drive(1,6);}
					else{
						motor_disable();
						HAL_Delay(200);
						flag_calib=1;
						ssd1306_Fill(Black);
						ssd1306_SetCursor(0,0);
						ssd1306_WriteString( "Mode 2 activated",Font_7x10,White);
						
						
						sprintf(oled_data,"posX = %f",position[0]);
						ssd1306_SetCursor(0,24);
						ssd1306_WriteString( oled_data,Font_7x10,White);
						
						sprintf(oled_data,"posY = %f",position[1]);
						ssd1306_SetCursor(0,36);
						ssd1306_WriteString( oled_data,Font_7x10,White);
						
						sprintf(oled_data,"posZ = %f",position[2]);
						ssd1306_SetCursor(0,48);
						ssd1306_WriteString( oled_data,Font_7x10,White);
						ssd1306_UpdateScreen();
						flag_calib=0;
					}
					
				}
				break;
			case 3 :	// Demo 3, maintain initial yaw
				if(HAL_GetTick() - mode_timer < 3000){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 3",Font_7x10,White);
					ssd1306_UpdateScreen();
				}
				else if(HAL_GetTick() - mode_timer >= 3000 &&  HAL_GetTick() - mode_timer < 3100){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 3 activated",Font_7x10,White);
					ssd1306_UpdateScreen();
				}
				else{
					if(flag_mode3==0){
						ssd1306_Fill(Black);
						ssd1306_SetCursor(0,0);
						ssd1306_WriteString( "Mode 3 activated",Font_7x10,White);
						ssd1306_SetCursor(14,22);
						ssd1306_WriteString( "KICK IT !",Font_11x18,White);
						ssd1306_UpdateScreen();
						motor_cnt=0;
						flag_calib=0;
						flag_mode3=1;
						flag_yaw=1;
					}
					if(cnt_mode3 >= 1000){
					while(angle[2] < -1) {
						
							motor_drive(3,12);
						}
					while(angle[2] > +1) {
						
							motor_drive(4,12);
						}
					}
					else motor_disable();
					
					
					
				}
				break;
			case 4:	// Demo 4, Free possition calculation (motors not active)
				if(HAL_GetTick() - mode_timer < 3000){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 4",Font_7x10,White);
					ssd1306_UpdateScreen();
				}
				else if(HAL_GetTick() - mode_timer >= 3000 &&  HAL_GetTick() - mode_timer < 3100){
					ssd1306_Fill(Black);
					ssd1306_SetCursor(0,0);
					ssd1306_WriteString( "Mode 4 activated",Font_7x10,White);
					ssd1306_UpdateScreen();
					flag_mode_select=1;
				}
				else{
					if(flag_mode4==0){
						ssd1306_Fill(Black);
						ssd1306_SetCursor(0,0);
						ssd1306_WriteString( "Mode 4 activated",Font_7x10,White);
						ssd1306_SetCursor(14,20);
						ssd1306_WriteString( "MOVE IT !",Font_11x18,White);
						ssd1306_SetCursor(0,40);
						ssd1306_WriteString( "Press button",Font_7x10,White);
						ssd1306_SetCursor(0,52);
						ssd1306_WriteString( "to measure",Font_7x10,White);
						ssd1306_UpdateScreen();
						flag_yaw=0;
						flag_calib=0;						
						flag_mode4=1;
					}
					
					if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_5)){ 
						HAL_Delay(200);
						while(1){	
							if(flag_mode4==1){
								flag_calib=1;
								quat2euler(&angle[0]);
								
								
								ssd1306_Fill(Black);
								ssd1306_SetCursor(0,0);
								ssd1306_WriteString( "Mode 4 activated",Font_7x10,White);
							
								
								sprintf(oled_data,"posX = %f",position[0]);
								ssd1306_SetCursor(0,24);
								ssd1306_WriteString( oled_data,Font_7x10,White);
								
								sprintf(oled_data,"posY = %f",position[1]);
								ssd1306_SetCursor(0,36);
								ssd1306_WriteString( oled_data,Font_7x10,White);
								
								sprintf(oled_data,"posZ = %f",position[2]);
								ssd1306_SetCursor(0,48);
								ssd1306_WriteString( oled_data,Font_7x10,White);
								
								ssd1306_UpdateScreen();
								
								
							}
						}
					}
		}
		break;
	}
		if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_5)){ // Mode selecton
			if(flag_mode_select==0){
				HAL_Delay(200);
				mode++;
				mode_timer = HAL_GetTick();
				flag_calib=1;
				flag_mode1=0;
				flag_mode2=0;
				flag_mode3=0;
				flag_mode4=0;
				if(mode>4){mode=0;}
			}
		}		
  }

  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Common config 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* I2C1 init function */
static void MX_I2C1_Init(void)
{

  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 72;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART2 init function */
static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15 
                          |GPIO_PIN_4|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB12 PB13 PB14 PB15 
                           PB4 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15 
                          |GPIO_PIN_4|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PA8 PA9 PA10 PA11 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB3 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_SYSTICK_Callback(void){
	
	elapsed_time[1] = __HAL_TIM_GET_COUNTER(&htim2);	// Timer to see the time spent on systick
	cnt_blink ++;
	if(flag_calib == 0){
		get_mpu_values (); 															// Read raw data from sensor
		
		if(flag_yaw==0){																// When there is no need for euler angle
			acc_tmp[0] = (raw_accX) * 0.0005987548828125;       acc_tmp[1] = (raw_accY) * 0.0005987548828125;       acc_tmp[2] = (raw_accZ) * 0.0005987548828125-0.052; 	// 0.0005987548828125 = 9.81/16384
			quat_2[0] = (raw_gyrX-calib[3]) * 0.00026646248122; quat_2[1] = (raw_gyrY-calib[4]) * 0.00026646248122; quat_2[2] = (raw_gyrZ-calib[5]) * 0.00026646248122;   // 0.00026646248122 = pi/180/65.5
			acc_magn= sqrt(acc_tmp[0]*acc_tmp[0] + acc_tmp[1]*acc_tmp[1] + acc_tmp[2]*acc_tmp[2]);
			calc_quat(&quat_2[0],&acc_tmp[0],&quat_old[0],&quat[0]);	
			quat_old[0]=quat[0]; quat_old[1]=quat[1]; quat_old[2]=quat[2]; quat_old[3]=quat[3];
		
			quat_rotate(&acc_tmp[0],&quat[0],&acc_rotated[0]);
			calc_pos(&acc_rotated[0]);			
		}
		else if(flag_yaw==1){ 													// Only in yawing  - no position calculation!!
		
			acc_tmp[0] = (raw_accX) * 0.0005987548828125; acc_tmp[1] = (raw_accY) * 0.0005987548828125; acc_tmp[2] = (raw_accZ) * 0.0005987548828125; 									 // 0.0005987548828125 = 9.81/16384
			quat_2[0] = (raw_gyrX-calib[3]) * 0.00026646248122; quat_2[1] = (raw_gyrY-calib[4]) * 0.00026646248122; quat_2[2] = (raw_gyrZ-calib[5]) * 0.00026646248122;  // 0.00026646248122 = pi/180/65.5
		
			calc_quat(&quat_2[0],&acc_tmp[0],&quat_old[0],&quat[0]);	
			quat2euler(&angle[0]);		
			quat_old[0]=quat[0]; quat_old[1]=quat[1]; quat_old[2]=quat[2]; quat_old[3]=quat[3];
		}
		
		if(angle[2] < -1 || angle[2] > 1){
			cnt_mode3++;
		}
		else{cnt_mode3=0;}
		
		
		cnt_blink ++;																	// System on bilnk
		if(cnt_blink>=250){
			HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_13);
			cnt_blink=0;
		}
	}
	
	elapsed_time[0] = __HAL_TIM_GET_COUNTER(&htim2) - elapsed_time[1];
}
// functions
void quat2euler(float *angle){
	*(angle+2)= atan2f(2*(quat[1]*quat[2]+quat[0]*quat[3]), quat[0]*quat[0] + quat[1]*quat[1] - quat[2]*quat[2] - quat[3]*quat[3])*180/pi;
	*(angle+1)= asinf(-2*(quat[1])*quat[3] - quat[0]*quat[2])*180/pi;
	*angle    = atan2f(2*(quat[2]*quat[3]+quat[0]*quat[1]), quat[0]*quat[0] - quat[1]*quat[1] - quat[2]*quat[2] + quat[3]*quat[3])*180/pi;
}
void calc_quat(float *gyro ,float *accel ,float *quat_old, float *quat){	
	float tmp_q[4],tmp_norm, tmp_gyro[4]={0,*gyro,*(gyro+1),*(gyro+2)};
	float acc_normed[3]={*accel,*(accel+1),*(accel+2)},acc_magn,step_norm;
	float beta=0.01;
	//J[12],F[3],step[4],beta;
		
	acc_magn= sqrt(acc_normed[0]*acc_normed[0]+acc_normed[1]*acc_normed[1]+acc_normed[2]*acc_normed[2]);
	
	if(  9.76 < acc_magn && acc_magn < 9.86 ){ beta = 0.02;	} 					// is unity ?
	else {beta=0;}
	
	acc_normed[0] = acc_normed[0] / acc_magn;
	acc_normed[1] = acc_normed[1] / acc_magn;
	acc_normed[2] = acc_normed[2] / acc_magn;
	
	F[0]=2*( *(quat_old+1) * *(quat_old+3) - *(quat_old  ) * *(quat_old+2)) - acc_normed[0];
	F[1]=2*( *(quat_old  ) * *(quat_old+1) + *(quat_old+2) * *(quat_old+3)) - acc_normed[1];
	F[2]=2*( 0.5 - *(quat_old+1) * *(quat_old+1) - *(quat_old+2) * *(quat_old+2)) - acc_normed[2];
	
	J[0]= -2 * *(quat_old+2);			J[1]=  2 * *(quat_old+3);			J[2] = -2 * *(quat_old  );			J[3]=  2 * *(quat_old+1);			
	J[4]=  2 * *(quat_old+1);			J[5]=  2 * *(quat_old+0);			J[6] =  2 * *(quat_old+3);			J[7]=  2 * *(quat_old+2);			
	J[8]= 0									;			J[9]= -4 * *(quat_old+1);			J[10]= -4 * *(quat_old+2);			J[11]= 0;			
	
	step[0]= J[0]*F[0] + J[4]*F[1] + J[8 ]*F[2]; 
	step[1]= J[1]*F[0] + J[5]*F[1] + J[9 ]*F[2]; 
	step[2]= J[2]*F[0] + J[6]*F[1] + J[10]*F[2]; 
	step[3]= J[3]*F[0] + J[7]*F[1] + J[11]*F[2]; 

	step_norm = sqrt(step[0]*step[0]+step[1]*step[1]+step[2]*step[2]+step[3]*step[3]);
	
	step[0] = step[0] / step_norm;
	step[1] = step[1] / step_norm;
	step[2] = step[2] / step_norm;
	step[3] = step[3] / step_norm;
	
	quat_prod(quat_old,&tmp_gyro[0],&tmp_q[0]); 
		//beta=0.03;
	//qDot = tmp_q
		tmp_q[0]	=  tmp_q[0] * 0.5 - beta * step[0];
		tmp_q[1]	=  tmp_q[1] * 0.5 - (beta*4) * step[1];
		tmp_q[2]	=  tmp_q[2] * 0.5 - (beta*4) * step[2];
		tmp_q[3]	=  tmp_q[3] * 0.5 - beta * step[3];
		
		tmp_q[0]	= *quat_old     + tmp_q[0] * dt ;
		tmp_q[1]	= *(quat_old+1) + tmp_q[1] * dt ;
		tmp_q[2]	= *(quat_old+2) + tmp_q[2] * dt ;
		tmp_q[3]	= *(quat_old+3) + tmp_q[3] * dt ;
	
	tmp_norm = sqrt(tmp_q[0]*tmp_q[0]+tmp_q[1]*tmp_q[1]+tmp_q[2]*tmp_q[2]+tmp_q[3]*tmp_q[3]); //make function after
	
	*quat     = tmp_q[0]/tmp_norm;
	*(quat+1) = tmp_q[1]/tmp_norm;
	*(quat+2) = tmp_q[2]/tmp_norm;
	*(quat+3) = tmp_q[3]/tmp_norm;		
}
void quat_rotate(float *v1, float *q,float *v2){ 
	float tmp_v[4] = {0,*v1,*(v1+1),*(v1+2)};
	float tmp_q[4],tmp_c[4],tmp_r[4];
	
	quat_prod(q,&tmp_v[0],&tmp_q[0]);
	quat_conj(q,&tmp_c[0]);
	quat_prod(&tmp_q[0],&tmp_c[0],&tmp_r[0]);
	*v2 = tmp_r[1]; *(v2+1) = tmp_r[2]; *(v2+2) = tmp_r[3]-9.81;
	
}
void quat_prod(float *q1, float *q2, float *q3){
	*q3			 = (*q1)*(*q2)  - (*(q1+1))*(*(q2+1)) - (*(q1+2))*(*(q2+2)) - (*(q1+3))*(*(q2+3)) ;
	*(q3+1)  = (*q1)*(*(q2+1))  + (*(q1+1))*(*q2) + (*(q1+2))*(*(q2+3)) - (*(q1+3))*(*(q2+2)) ;
	*(q3+2)  = (*q1)*(*(q2+2))  - (*(q1+1))*(*(q2+3)) + (*(q1+2))*(*q2) + (*(q1+3))*(*(q2+1)) ;
	*(q3+3)  = (*q1)*(*(q2+3))  + (*(q1+1))*(*(q2+2)) - (*(q1+2))*(*(q2+1)) + (*(q1+3))*(*q2) ;
}
void quat_conj (float *q1, float *q2){
	*q2 = *q1;
	*(q2+1)	= *(q1+1)	*-1;
	*(q2+2)	= *(q1+2) *-1;
	*(q2+3) = *(q1+3)	*-1;	
}

void calc_pos( float *Accel){
//position calculation variables
//uint8_t flag_zero_update=1,flag_zero_update_old=1, flag_pos_update;  
//uint16_t	counter_zero_update, counter_offset_update;
//float offset,acc_old, pos, speed,speed_old, acu, pos_update[5];
	
	float acc[3]={ *Accel, *(Accel+1), *(Accel+2)};
	float border[2]={0.8,0.15};
	//################### POSSITION X ###################
	acc[0] -= offset[0];
	speed[0] += (acc[0]+acc_old[0])*0.5*dt;
	
	if(fabs(acc[0]-acc_old[0])<border[0] && fabs(acc[0])<border[1]){ //
		counter_zero_update[0]++;
		acu[0] += acc[0];
		if(counter_zero_update[0] >= 150){
			flag_zero_update[0]=1;
			offset[0]=acu[0]/150;
			if(flag_zero_update_old[0] == 0){  //detect risign edge of flag_zero_update[0]
				pos_update[0][2] = HAL_GetTick();
				pos_update[0][3] = speed[0];
				
				pos_update[0][4] = (pos_update[0][2]-pos_update[0][0])*(pos_update[0][3]-pos_update[0][1])*dt*0.5;
				position[0] = position[0] - pos_update[0][4];
			}
			speed[0]=0;  acu[0]=0; //counter_zero_update[0] = 0;
		}
	}
	else{
		flag_zero_update[0]=0; 
		if(flag_zero_update_old[0] == 1){
			pos_update[0][0]=HAL_GetTick();
			pos_update[0][1]=speed[0];			
		}
		counter_offset_update[0]++;
		if(counter_offset_update[0]>250){
			//offset[0]=0; 
			counter_offset_update[0]=0;
		}
		acu[0]=0; counter_zero_update[0] = 0;
	}		
		
	position[0] += (speed[0]+speed_old[0])*0.5*dt; 
	
	acc_old[0]=acc[0];
	flag_zero_update_old[0]=flag_zero_update[0];
	speed_old[0]=speed[0];
	
		//################### POSSITION Y ###################
	acc[1] -= offset[1];
	speed[1] += (acc[1]+acc_old[1])*0.5*dt;
	
		if(fabs(acc[1]-acc_old[1])<border[0] && fabs(acc[1])<border[1]){ // //
		counter_zero_update[1]++;
		acu[1] += acc[1];
		if(counter_zero_update[1] >= 150){
			flag_zero_update[1]=1;
			offset[1]=acu[1]/150;
			if(flag_zero_update_old[1] == 0){  //detect risign edge of flag_zero_update[1]
				pos_update[1][2] = HAL_GetTick();
				pos_update[1][3] = speed[1];
				
				pos_update[1][4] = (pos_update[1][2]-pos_update[1][0])*(pos_update[1][3]-pos_update[1][1])*dt*0.5;
				position[1] = position[1] - pos_update[1][4];
			}
			speed[1]=0;  acu[1]=0; //counter_zero_update[1] = 0;
		}
	}
	else{
		flag_zero_update[1]=0; 
		if(flag_zero_update_old[1] == 1){
			pos_update[1][0]=HAL_GetTick();
			pos_update[1][1]=speed[1];			
		}
		counter_offset_update[1]++;
		if(counter_offset_update[1]>250){
			//offset[1]=0; 
			counter_offset_update[1]=0;
		}
		acu[1]=0; counter_zero_update[1] = 0;
	}		
		
	position[1] += (speed[1]+speed_old[1])*0.5*dt; 
	
	acc_old[1]=acc[1];
	flag_zero_update_old[1]=flag_zero_update[1];
	speed_old[1]=speed[1];

		//################### POSSITION Z ###################
	acc[2] -= offset[2];
	speed[2] += (acc[2]+acc_old[2])*0.5*dt;
	
	if(fabs(acc[2]-acc_old[2])<(border[0]+0.05) && fabs(acc[2])<(border[1])+0.04){ //
		counter_zero_update[2]++;
		acu[2] += acc[2];
		if(counter_zero_update[2] >= 150){
			flag_zero_update[2]=1;
			offset[2]=acu[2]/150;
			if(flag_zero_update_old[2] == 0){  //detect risign edge of flag_zero_update[2]
				pos_update[2][2] = HAL_GetTick();
				pos_update[2][3] = speed[2];
				
				pos_update[2][4] = (pos_update[2][2]-pos_update[2][0])*(pos_update[2][3]-pos_update[2][1])*dt*0.5;
				position[2] = position[2] - pos_update[2][4];
			}
			speed[2]=0; acu[2]=0; //counter_zero_update[2] = 0; 
		}
	}
	else{
		flag_zero_update[2]=0; 
		if(flag_zero_update_old[2] == 1){
			pos_update[2][0]=HAL_GetTick();
			pos_update[2][1]=speed[2];			
		}
		counter_offset_update[2]++;
		if(counter_offset_update[2]>250){
			//offset[2]=0; 
			counter_offset_update[2]=0;
		}
		acu[2]=0; counter_zero_update[2] = 0;
	}		
		
	position[2] += (speed[2]+speed_old[2])*0.5*dt; 
	
	acc_old[2]=acc[2];
	flag_zero_update_old[2]=flag_zero_update[2];
	speed_old[2]=speed[2];
	
}
void motor_disable(void){
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);			//DISABLE MOTORS
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);		
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
}

void motor_drive(uint8_t select ,uint16_t step_time){
	
	if(HAL_GetTick()-ms_motor <(step_time-1)){
		if(flag_motor == 0){
			switch (select)	{
				case 1 :
					forward();
					break;
				case 2 :
					backward();
					break;
				case 3 :
					left();
					break;
				case 4 :
					right();
					break;		
			}flag_motor=1;
		}
	}
	else if (HAL_GetTick()-ms_motor >= step_time)		{ms_motor=HAL_GetTick(); flag_motor=0;}
	else  {motor_disable();}
		
}
void forward(void){
	step_phase++;
	switch (step_phase)	{
		case 1 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);			
			
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 2 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_RESET);
			break;
		
		case 3 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_SET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 4 :	
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			step_phase=0;	
			break;	
	}
}		


void backward(void){
	step_phase++;
	switch (step_phase)	{
		case 1 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 2 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_SET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 3 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_RESET);
			break;
		
		case 4 :	
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);			
			
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			step_phase=0;	
			break;	
	}
}	


void left(void){
	step_phase++;
	switch (step_phase)	{
		case 1 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);
			
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 2 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_SET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 3 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_RESET);
			break;
		
		case 4 :	
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			step_phase=0;	
			break;	
	}
}


void right(void){
	step_phase++;
	switch (step_phase)	{
		case 1 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);
		
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 2 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_RESET);
			break;
		
		case 3 :
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_SET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			break;
		
		case 4 :	
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);

			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_9,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_8,GPIO_PIN_SET);
			step_phase=0;	
			break;	
	}
}


void get_mpu_values (void){
	buffer[0]=0x3B; //Start from this register
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,1,100); //Send start address
	HAL_I2C_Master_Receive(&hi2c1,0x68<<1,buffer,14,200); //Start reading
	
	raw_accX = buffer[0]<<8 | buffer[1];
	raw_accY = buffer[2]<<8 | buffer[3];
	raw_accZ = buffer[4]<<8 | buffer[5];	
	raw_tmp  = buffer[6]<<8 | buffer[7];
	raw_gyrX = buffer[8]<<8 | buffer[9];
	raw_gyrY = buffer[10]<<8 | buffer[11];
	raw_gyrZ = buffer[12]<<8 | buffer[13];
	
}

void calibration ( void){
	flag_calib = 1; 
	for (int i=0;i<2000;i++){
	get_mpu_values();
	HAL_Delay(1);
	
	calib[0] += raw_accX * 0.0005;
	calib[1] += raw_accY * 0.0005;
	calib[2] += raw_accZ * 0.0005;
	
	calib[3] += raw_gyrX * 0.0005;
	calib[4] += raw_gyrY * 0.0005;
	calib[5] += raw_gyrZ * 0.0005;
		
		cnt_blink ++;
		if(cnt_blink>=50){
			HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_13);
			cnt_blink=0;
		}

	}
	float roll  = atan2( calib[1],sqrt(calib[0]*calib[0]+calib[2]*calib[2]));
  float pitch = atan2(-calib[0],sqrt(calib[1]*calib[1]+calib[2]*calib[2]));

	
	float cy = 1;
	float sy = 0;
	float cr = cos(roll * 0.5);
	float sr = sin(roll * 0.5);
	float cp = cos(pitch * 0.5);
	float sp = sin(pitch * 0.5);

	quat[0] = cy * cr * cp + sy * sr * sp;
	quat[1] = cy * sr * cp - sy * cr * sp;
	quat[2] = cy * cr * sp + sy * sr * cp;
	quat[3] = sy * cr * cp - cy * sr * sp;
	
	quat_old[0]=quat[0];
	quat_old[1]=quat[1];
	quat_old[2]=quat[2];
	quat_old[3]=quat[3];
	
	//calib[2]= calib[2] - 16384;
	speed[0]=0;		 speed[1]=0;			speed[2]=0;	
	position[0]=0; position[1]=0; 	position[2]=0;
	quat[0]=1;	quat[1]=0;	quat[2]=0;	quat[3]=0;

	//flag_calib=0;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
