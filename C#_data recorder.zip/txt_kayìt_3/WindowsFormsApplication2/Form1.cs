﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using System.Threading;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        bool flag_dur = false;
        string[] ports = SerialPort.GetPortNames();        
        private Thread okuma_baslat;
        StreamWriter txt_yaz;
        
        SerialPort my_serial = new SerialPort();

        public Form1()
        {
            InitializeComponent();
            get_ports();

        }


        public void get_ports()
        {
            foreach (string port in ports)
            {
                box_com.Items.Add(port);
            }
            box_com.SelectedIndex =0;
            box_baud.SelectedIndex = 2;
            box_bit.SelectedIndex = 1;
            box_stop.SelectedIndex = 0;
            box_parity.SelectedIndex = 0;
            label_durum.Text = "HAZIR";
        }

        public void setup_serial()
        {
            my_serial.PortName = box_com.Text ;
            my_serial.BaudRate = int.Parse(box_baud.Text);
            my_serial.DataBits = int.Parse(box_bit.Text);

            if ((box_parity.Text) == "None") my_serial.Parity = Parity.None;
            else if ((box_parity.Text) == "Odd") my_serial.Parity = Parity.Odd;
            else if ((box_parity.Text) == "Even") my_serial.Parity = Parity.Even;
            else if ((box_parity.Text) == "Mark") my_serial.Parity = Parity.Mark;
            else if ((box_parity.Text) == "Space") my_serial.Parity = Parity.Space;

            if ((box_stop.Text) == "One") my_serial.StopBits = StopBits.One;
            else if ((box_stop.Text) == "Two") my_serial.StopBits = StopBits.Two;
            else if ((box_stop.Text) == "Opf") my_serial.StopBits = StopBits.OnePointFive;
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            try
            {
                if (my_serial.IsOpen == false)
                {
                    setup_serial();
                    my_serial.Open();
                    label_durum.Text = "PORTA BAĞLANILDI";
                    //yazmaya_basla();

                }
            }
            catch (Exception ex)
            {
                label_durum.Text = "PORTA BAĞLANILAMADI";
                MessageBox.Show(ex.Message);
            }
        }

        private void button_stop_Click(object sender, EventArgs e)
        {
            try
            {
                if (my_serial.IsOpen == true)
                {
                    my_serial.Close();
                    label_durum.Text = "PORT BAĞLANTISI DURDURULDU";
                }
            }
            catch (Exception ex)
            {
                label_durum.Text = "PORT BAĞLANTISI DURDURULAMADI";
                MessageBox.Show(ex.Message);
            }

        }


        
        private void button_yaz_Click(object sender, EventArgs e)
        {

            yazmaya_basla();

        }
        private void yazmaya_basla(){
            label_durum.Text = "YAZMA İŞLEMİ BAŞLADI";
            txt_yaz = new StreamWriter("raw_data.txt");
            okuma_baslat = new Thread(new ThreadStart(seri_port_veri_al));
            okuma_baslat.Priority = ThreadPriority.AboveNormal;
            okuma_baslat.IsBackground = true;
            flag_dur = false;
            okuma_baslat.Start();
        }


        
        void seri_port_veri_al()
        {
            while (!flag_dur | my_serial.BytesToRead > 20)
            {
                if (my_serial.ReadByte() == 5)
                {
                    if (my_serial.ReadByte() == 43)
                    {
                        txt_yaz.Write("0543" + "\t");
                        txt_yaz.Write(Convert.ToString(my_serial.ReadByte()) + "\t");
                        txt_yaz.Write(Convert.ToString(my_serial.ReadByte()) + "\t");
                        byte[] data = new byte[14];
                        my_serial.Read(data, 0, 14);
                        for (int counter = 0; counter < 14; counter = counter + 2) {
                            short data_16 = (short)(data[counter] << 8 | data[counter + 1]);
                            txt_yaz.Write(Convert.ToString(data_16) + "\t");
                        } txt_yaz.WriteLine("");
                    }
                }
            }
            txt_yaz.WriteLine("There is {0} data on buffer", my_serial.BytesToRead);
            yazmayı_durdur();
        }


        private void button_yazmadur_Click(object sender, EventArgs e)
        {
            yazmayı_durdur();
            label_durum.Text = "YAZMA İŞLEMİ DURDURULDU";
        }
        private void yazmayı_durdur()
        {
            
            flag_dur = true;
            Thread.Sleep(1000);
            okuma_baslat.Abort();
            txt_yaz.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }


    }
}
