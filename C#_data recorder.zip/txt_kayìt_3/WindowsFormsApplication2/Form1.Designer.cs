﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box_com = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.box_baud = new System.Windows.Forms.ComboBox();
            this.box_bit = new System.Windows.Forms.ComboBox();
            this.box_stop = new System.Windows.Forms.ComboBox();
            this.box_parity = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_durum = new System.Windows.Forms.Label();
            this.button_start = new System.Windows.Forms.Button();
            this.button_stop = new System.Windows.Forms.Button();
            this.button_yaz = new System.Windows.Forms.Button();
            this.button_yazmadur = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // box_com
            // 
            this.box_com.FormattingEnabled = true;
            this.box_com.Location = new System.Drawing.Point(12, 25);
            this.box_com.Name = "box_com";
            this.box_com.Size = new System.Drawing.Size(121, 21);
            this.box_com.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "com";
            // 
            // box_baud
            // 
            this.box_baud.FormattingEnabled = true;
            this.box_baud.Items.AddRange(new object[] {
            "9600",
            "115200",
            "230400"});
            this.box_baud.Location = new System.Drawing.Point(12, 79);
            this.box_baud.Name = "box_baud";
            this.box_baud.Size = new System.Drawing.Size(121, 21);
            this.box_baud.TabIndex = 2;
            // 
            // box_bit
            // 
            this.box_bit.FormattingEnabled = true;
            this.box_bit.Items.AddRange(new object[] {
            "7",
            "8",
            "9"});
            this.box_bit.Location = new System.Drawing.Point(12, 133);
            this.box_bit.Name = "box_bit";
            this.box_bit.Size = new System.Drawing.Size(121, 21);
            this.box_bit.TabIndex = 3;
            // 
            // box_stop
            // 
            this.box_stop.FormattingEnabled = true;
            this.box_stop.Items.AddRange(new object[] {
            "One",
            "Two",
            "Opt"});
            this.box_stop.Location = new System.Drawing.Point(12, 186);
            this.box_stop.Name = "box_stop";
            this.box_stop.Size = new System.Drawing.Size(121, 21);
            this.box_stop.TabIndex = 4;
            // 
            // box_parity
            // 
            this.box_parity.FormattingEnabled = true;
            this.box_parity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space"});
            this.box_parity.Location = new System.Drawing.Point(12, 237);
            this.box_parity.Name = "box_parity";
            this.box_parity.Size = new System.Drawing.Size(121, 21);
            this.box_parity.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "baud";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "lenght";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "stop bit";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "parity";
            // 
            // label_durum
            // 
            this.label_durum.AutoSize = true;
            this.label_durum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_durum.Location = new System.Drawing.Point(164, 186);
            this.label_durum.Name = "label_durum";
            this.label_durum.Size = new System.Drawing.Size(46, 17);
            this.label_durum.TabIndex = 10;
            this.label_durum.Text = "label6";
            // 
            // button_start
            // 
            this.button_start.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_start.Location = new System.Drawing.Point(167, 53);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(75, 23);
            this.button_start.TabIndex = 12;
            this.button_start.Text = "Bağlan";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // button_stop
            // 
            this.button_stop.Location = new System.Drawing.Point(167, 112);
            this.button_stop.Name = "button_stop";
            this.button_stop.Size = new System.Drawing.Size(75, 23);
            this.button_stop.TabIndex = 13;
            this.button_stop.Text = "Durdur";
            this.button_stop.UseVisualStyleBackColor = true;
            this.button_stop.Click += new System.EventHandler(this.button_stop_Click);
            // 
            // button_yaz
            // 
            this.button_yaz.Location = new System.Drawing.Point(275, 53);
            this.button_yaz.Name = "button_yaz";
            this.button_yaz.Size = new System.Drawing.Size(75, 23);
            this.button_yaz.TabIndex = 15;
            this.button_yaz.Text = "Txt kayıt";
            this.button_yaz.UseVisualStyleBackColor = true;
            this.button_yaz.Click += new System.EventHandler(this.button_yaz_Click);
            // 
            // button_yazmadur
            // 
            this.button_yazmadur.Location = new System.Drawing.Point(275, 112);
            this.button_yazmadur.Name = "button_yazmadur";
            this.button_yazmadur.Size = new System.Drawing.Size(75, 23);
            this.button_yazmadur.TabIndex = 16;
            this.button_yazmadur.Text = "Kaydı durdur";
            this.button_yazmadur.UseVisualStyleBackColor = true;
            this.button_yazmadur.Click += new System.EventHandler(this.button_yazmadur_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(353, 255);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Y.K.T.";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 277);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_yazmadur);
            this.Controls.Add(this.button_yaz);
            this.Controls.Add(this.button_stop);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.label_durum);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.box_parity);
            this.Controls.Add(this.box_stop);
            this.Controls.Add(this.box_bit);
            this.Controls.Add(this.box_baud);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.box_com);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(420, 316);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox box_com;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox box_baud;
        private System.Windows.Forms.ComboBox box_bit;
        private System.Windows.Forms.ComboBox box_stop;
        private System.Windows.Forms.ComboBox box_parity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_durum;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Button button_stop;
        private System.Windows.Forms.Button button_yaz;
        private System.Windows.Forms.Button button_yazmadur;
        private System.Windows.Forms.Label label6;
    }
}

