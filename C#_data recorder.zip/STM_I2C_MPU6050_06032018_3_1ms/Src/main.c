/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */
#include <string.h>
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_tx;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

unsigned char buffer[20];
int zero_vel_cnt_X,zero_vel_cnt_Y,zero_vel_cnt_Z;	
float acu[7];
uint8_t cnt,flag_1ms_elapsed,logging;
int16_t raw_accX,raw_accY,raw_accZ,raw_tmp,raw_gyrX,raw_gyrY,raw_gyrZ;  //from raw values on sensor
float accX,accY,accZ,tmp,gyrX,gyrY,gyrZ;
float cal_accX,cal_accY,cal_accZ,cal_gyrX,cal_gyrY,cal_gyrZ;
float angle_X,angle_Y,angle_Z,pos_X,pos_Y,pos_Z,vel_X,vel_Y,vel_Z;
char txData[100];
uint16_t ms_time=0;
uint16_t len=0;



/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART1_UART_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
	void get_mpu_values (void);
	//void calibrate(void);
	//void calculate_real_values(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();

  /* USER CODE BEGIN 2 */
	HAL_Delay(10);
	
  buffer[0]=0x6b; //register address to wake up mpu6050
	buffer[1]=0;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);
	
	buffer[0]=0x1C; //register address to configure accelerometer (+-2g max)(16384 = 1g)
	buffer[1]=0;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);

	buffer[0]=0x1a; //Configure the digital low pass (DLPF_CFG=3)(bandw = 44, delay 4.9 ms)
	buffer[1]=0;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);
	
	buffer[0]=0x1b; //Configure the gyro  (+- 500  �/s)(65.5 =�/s)
	buffer[1]=8;	
	HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,2,100);
	HAL_Delay(10);
	
	//calibrate(); //run calibrate function
	HAL_Delay(10);
	
	ms_time=HAL_GetTick();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
		get_mpu_values ();
		//sprintf(txData,"%d\t",ms_time);
		//sprintf(txData,"%d\t%d\t%d\t%d\t%d\t%d\t%d\r\n",ms_time,raw_accX,raw_accY,raw_accZ,raw_gyrX,raw_gyrY,raw_gyrZ);
		//len=strlen(txData);
		HAL_UART_Transmit_DMA(&huart1,buffer,18);
		while(HAL_GetTick()-ms_time<1){
		}
		ms_time=HAL_GetTick();

  }
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* I2C1 init function */
static void MX_I2C1_Init(void)
{

  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART1 init function */
static void MX_USART1_UART_Init(void)
{

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 230400;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PB13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
	void HAL_SYSTICK_Callback(void){
		cnt++;
		if(cnt >= 125){
				HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_13);//check systick timer runs correctly by blinking LED
				cnt=0;
		}
	}

	
	void get_mpu_values ( ){
		buffer[0]=0x3B;
		HAL_I2C_Master_Transmit(&hi2c1,0x68<<1,buffer,1,100);
		
		HAL_I2C_Master_Receive(&hi2c1,0x68<<1,buffer,14,200);//start reading
		//buffer[0] : MSB data
		//buffer[1] : LSB data
		
		raw_accX = buffer[0]<<8 | buffer[1];
		raw_accY = buffer[2]<<8 | buffer[3];
		raw_accZ = buffer[4]<<8 | buffer[5];	
		raw_tmp  = buffer[6]<<8 | buffer[7];
		raw_gyrX = buffer[8]<<8 | buffer[9];
		raw_gyrY = buffer[10]<<8 | buffer[11];
		raw_gyrZ = buffer[12]<<8 | buffer[13];
		buffer[14]='\n';
		buffer[15]=5;			// header 1
		buffer[16]=43;		// header 2
		buffer[17]=cnt;
		
		
	/*	accX  = (float)raw_accX / 16384 - cal_accX;				//in unit g
		accY  = (float)raw_accY / 16384 - cal_accY;	
		accZ  = (float)raw_accZ / 16384 - cal_accZ;
		tmp   = (float)raw_tmp/ 340 + 36.53;							// in unit celcius
		gyrX	= (float)raw_gyrX / 65.5 - cal_gyrX;				// in unit of degree per second
		gyrY  = (float)raw_gyrY / 65.5 - cal_gyrY;
		gyrZ  = (float)raw_gyrZ / 65.5 - cal_gyrZ;*/
		
		
		//acceleration always changes while in stagnant situation. We make zero the acceleration in this situation.
		/*
		if( (-0.02< accX) && (accX < 0.02) ){				accX=0;	}
		if( (-0.02< accY) && (accY < 0.02) ){				accY=0;	}
		if( (-0.02< accZ) && (accZ < 0.02) ){				accZ=0;	}
		
		
		calculate_real_values();
		*/
	}

/*		void calculate_real_values(){

			//calculation of angles
			
			angle_X += gyrX *0.001; 
			angle_Y += gyrY *0.001; 
			angle_Z += gyrZ *0.001; 
			
			
			//calculation of velocities
			
			vel_X += accX * 0.001 *9.8;
			vel_Y += accY * 0.001 *9.8;
			vel_Z += accZ * 0.001 *9.8;
			
			//if acceleration is zero for 50 ms, make zero the velocity
			
			if( (-0.02< accX) && (accX < 0.02)){
				zero_vel_cnt_X++;
			}
			else{
				zero_vel_cnt_X=0;
			}
			if( zero_vel_cnt_X>=50){
					vel_X=0;
			}

			
			
			if( (-0.02< accY) && (accY < 0.02)){
				zero_vel_cnt_Y++;
			}
			else{
				zero_vel_cnt_Y=0;
			}
			if( zero_vel_cnt_Y>=50){
					vel_Y=0;
			}
			
			
			
			if( (-0.02< accZ) && (accZ < 0.02)){
				zero_vel_cnt_Z++;
			}
			else{
				zero_vel_cnt_Z=0;
			}
			if( zero_vel_cnt_Z>=50){
					vel_Z=0;
			}
			
			
			//calculation of positions
			
			pos_X += vel_X *0.001; 
			pos_Y += vel_Y *0.001; 
			pos_Z += vel_Z *0.001;
			

			
			
		}*/
		
		/*void calibrate(){
			cal_accX=0; cal_accY=0; cal_accZ=0; cal_gyrX =0; cal_gyrY=0; cal_gyrZ=0;
			acu[1]=0; acu[2]=0; acu[3]=0; acu[4]=0; acu[5]=0; acu[6]=0; 
			int i=0;
			while(i<2000){
				get_mpu_values ();
				HAL_Delay(1);
				acu[1]= acu[1] + accX;
				acu[2]= acu[2] + accY;
				acu[3]= acu[3] + accZ;
				acu[4]= acu[4] + gyrX;
				acu[5]= acu[5] + gyrY;
				acu[6]= acu[6] + gyrZ;
					i++;
				HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_13);				
			}
			cal_accX=acu[1]/2000;
			cal_accY=acu[2]/2000;
			cal_accZ=acu[3]/2000;
			cal_gyrX=acu[4]/2000;
			cal_gyrY=acu[5]/2000;
			cal_gyrZ=acu[6]/2000;
			
			angle_X=0; angle_Y=0; angle_Z=0; vel_X=0; vel_Y=0; vel_Z=0; pos_X=0; pos_Y=0; pos_Z=0;
		}*/

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
