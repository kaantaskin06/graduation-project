%=====================================================
% Written by YAS�N KA�AN TA�KIN
% Date 07.03.2018
% v2 data stream smilation for easy to update stm32f103
% v3 zero update control every 200ms
% v4 zero and offset update control every 30ms
%=====================================================
clear all;
close all; 
clc

% fileID = fopen('raw_data_30.txt');
% raw = textscan(fileID,'%f %f %f %f %f %f %f %f %f %f','Delimiter','\t');
% fclose(fileID);
% [m,n]= size(raw{1});
load('matlab_87_2');
t=0.002;
%x=raw{1};
% y=raw{4}/16384*9.81;
 
 [m,n]= size(accZ);
z=accX; %65.5 %16384

acc_raw_speed=0;
acc_raw_possition=0;
z_old=0;
acc_raw_speed_old=0;


for i = 1:m
    %%%%%%%%%%%%%%%%% raw calculations %%%%%%%%%%%%%%%%%
    acc_raw_speed = acc_raw_speed + (t)*(z(i)+z_old)*0.5;
    z_old = z(i);
    raw_speed(i) =  acc_raw_speed;
    
    acc_raw_possition = acc_raw_possition +(t)*(acc_raw_speed+acc_raw_speed_old)*0.5;
    acc_raw_speed_old = acc_raw_speed;
    raw_possition(i) =  acc_raw_possition;    
end

subplot(3,2,1);
plot(z);
ylabel('Acc in m/s2')
title('stm32, sample freq 1kHz , RAW values matlab')

subplot(3,2,3);
plot(raw_speed);
ylabel('Speed in m/s')

subplot(3,2,5);
plot(raw_possition);
xlabel('Micro Second')
ylabel('Possition in meter')

acc_raw_speed=0;
acc_raw_possition=0;
z_old=0;
acc_raw_speed_old=0;
flag_zero_update=ones(1,m);
counter_zero_update=0;
counter_offset_update=0;
acc_zero_update=0;
offset=0;

position_update=zeros(1,4);
position_update_flag= zeros(1,m);
%%%%%%%%%%%%%%%%% CALIBRATION %%%%%%%%%%%%%%%%%

acc=0;
for i = 1:500
    acc = acc + z(i);
end
mean=acc/500;
z=z-mean;
acc=0;

% windowSize = 10;
% b = (1/windowSize)*ones(1,windowSize);
% a = 1;
% z =  filter(b,a,z);




for i = 1:m
    %%%%%%%%%%%%%%%%% processing part in loop %%%%%%%%%%%%%%%%%
    z(i)=z(i)-offset;
    acc_raw_speed = acc_raw_speed + (t)*((z(i)+z_old)*0.5);
    
    
  
    tmp= abs(z(i)-z_old);    % zero update control it controls changes 
    if tmp < 0.1 &&  abs(z(i))<0.1          % every 30 ms and calculate offset1
        counter_zero_update = counter_zero_update+1;
        acc_zero_update = acc_zero_update+z(i);
        flag_zero_update(i+1) = flag_zero_update(i);
        if counter_zero_update > 20;
            flag_zero_update(i+1) = 1;
            offset = offset + acc_zero_update / 20;            
            if(flag_zero_update(i) == 0)
                position_update(1,1)=i;
                position_update(1,2)=acc_raw_speed;
                position_update_flag(1,i)=1;
            %possition update
            update_pos=(position_update(1,4)-position_update(1,2))*(position_update(1,3)-position_update(1,1))*t*0.5;
            acc_raw_possition = acc_raw_possition-update_pos;
            end 
            

            
            acc_raw_speed=0;
            counter_zero_update = 0;
            acc_zero_update = 0;            
        end
    else
        flag_zero_update(i+1) = 0;
        if(flag_zero_update(i) == 1)
               position_update(1,3)=i;
               position_update(1,4)=acc_raw_speed;
               position_update_flag(1,i)=1;
            
        end
        counter_offset_update = counter_offset_update + 1;
        if counter_offset_update > 300
            offset=0;
            counter_offset_update=0;    
        end
        counter_zero_update = 0;
        acc_zero_update = 0;
    end                      % end zero update
        
    z_old = z(i);
    raw_speed(i) =  acc_raw_speed;    
    acc_raw_possition = acc_raw_possition + (t)*(acc_raw_speed+acc_raw_speed_old)*0.5;
    acc_raw_speed_old = acc_raw_speed;
    raw_possition(i) =  acc_raw_possition;       
       
end

subplot(3,2,2);
plot(z);
hold on;
plot(flag_zero_update);
ylabel('Acc in m/s2')
title('stm32, sample freq 1kHz , zero update v4 matlab')

subplot(3,2,4);
plot(raw_speed);
ylabel('Speed in m/s')

subplot(3,2,6);
plot(raw_possition);
xlabel('Micro Second')
ylabel('Possition in meter')

raw_possition(m)

 





