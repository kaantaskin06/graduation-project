function [ q_conj ] = quat_rotate( q )
%UNT�TLED2 vekt�r� quaternion ile d�nd�r
  q_conj = [q(1) -q(2) -q(3) -q(4)];
end

