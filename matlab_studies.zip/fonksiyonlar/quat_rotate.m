function [ v2 ] = quat_rotate( v, q )
%UNT�TLED2 vekt�r� quaternion ile d�nd�r ve yer �ekimini ��kart�r.
   v1= quat_prod(quat_prod(q, [0 v]), quat_conj(q));
   v2 = [v1(2) v1(3) v1(4)-1];
end

