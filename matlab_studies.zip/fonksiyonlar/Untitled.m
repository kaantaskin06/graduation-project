clear all;
clc;

q=[0.3 0.5 0.2 0.7874007874];
Acc=[0 1 0];
Gyr=[pi 0 0];
Beta = 0.01;
t_period=0.0001
    Acc_norm = Acc / norm(Acc);	% normalise magnitude

    % Gradient decent algorithm corrective step
    F = [2*(q(2)*q(4) - q(1)*q(3)) - Acc_norm(1,1)
        2*(q(1)*q(2) + q(3)*q(4)) - Acc_norm(1,2)
        2*(0.5 - q(2)^2 - q(3)^2) - Acc_norm(1,3)];

    J = [-2*q(3),	2*q(4),    -2*q(1),	2*q(2)
        2*q(2),     2*q(1),     2*q(4),	2*q(3)
        0,         -4*q(2),    -4*q(3),	0    ];
    
    step = (J'*F);
    step = step / norm(step);
    
    qDot = 0.5 * quat_prod(q, [0 Gyr(1,1)/180*pi Gyr(1,2)/180*pi Gyr(1,3)/180*pi]) - Beta * step';

    % Integrate to yield quaternion
    q = q + qDot * t_period;
    quaternion(1,:) = q / norm(q); % normalise quaternion