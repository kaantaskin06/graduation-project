%=====================================================
% Written by YAS�N KA�AN TA�KIN
% Date 18.04.2018
% v1 3d plot with out rotation (mpu6050 not rotate onw axis)
% v2 3d plot with rotation using quaternion (data set 17-18)
% v5 gait_track deneme
% v6 rotate acc with using gyo
% v7 rotate acc with using gyo and acc Madgwich algorithm 
% v8 total acc calculation
% v9 ivmenin y�ksek olmas� gerek, sonra total acc �al��am�yor
%=====================================================
clear all;
close all; 
clc

addpath('fonksiyonlar');
addpath('veriler');

%% Read the data set

% load('matlab_araba');
% [t,n]= size(accX);
% t_period=0.004;

fileID = fopen('raw_data_31.txt');
raw = textscan(fileID,'%f %f %f %f %f %f %f %f %f %f','Delimiter','\t');
fclose(fileID);
[t,n]= size(raw{1});
t_period=0.002;

Acc = [raw{3},raw{4},raw{5}]/16384;
Gyr = [raw{7},raw{8},raw{9}]/65.5;

%% Calibration

calib_num = 1000;
calib = zeros(1,7);
raw_total_grv=0;
for i = 1:calib_num
    calib(1) = calib(1) + Acc(i,1)/calib_num;
    calib(2) = calib(2) + Acc(i,2)/calib_num;
    calib(3) = calib(3) + Acc(i,3)/calib_num;
    calib(4) = calib(4) + Gyr(i,1)/calib_num;
    calib(5) = calib(5) + Gyr(i,2)/calib_num;
    calib(6) = calib(6) + Gyr(i,3)/calib_num;
    raw_total_grv = raw_total_grv + sqrt(Acc(i,1)^2 + Acc(i,2)^2 + Acc(i,3)^2)/calib_num;
end
Acc(:,1) = Acc(:,1) - calib(1); Acc(:,2) = Acc(:,2) - calib(2); Acc(:,3) = Acc(:,3) - calib(3)+1; 
Gyr(:,1) = Gyr(:,1) - calib(4); Gyr(:,2) = Gyr(:,2) - calib(5); Gyr(:,3) = Gyr(:,3) - calib(6);


% vaiables
accX_old=0;     speedX=0;   speedX_old=0;   possitionX=0;   offsetX=0;  counter_zero_updateX=0; zero_updateX=0; counter_offset_updateX=0;
accY_old=0;     speedY=0;   speedY_old=0;   possitionY=0;   offsetY=0;  counter_zero_updateY=0; zero_updateY=0; counter_offset_updateY=0;
accZ_old=0;     speedZ=0;   speedZ_old=0;   possitionZ=0;   offsetZ=0;  counter_zero_updateZ=0; zero_updateZ=0; counter_offset_updateZ=0;
flag_zero_update=zeros(t,1);
% gyr_yaw = 0;    gyr_pitch = 0;  gyr_roll = 0;
quaternion = zeros(t,4);    first_angle = zeros(1,3); 
Gyr_old=zeros(1,3);     Angle_tmp=zeros(1,3);
Speed=zeros(t,3);       Position=zeros(t,3);   acc_mag=zeros(t+3,1);  flag=zeros(t,1);
Acc_rotated=zeros(t,3);       
q = [1 0 0 0]; Beta = 0.01; 

%% initialize fist orientation
% first_angle(1,1) = atand(calib(2)/sqrt(calib(3)^2+calib(1)^2));
% first_angle(1,2) = atand(-calib(2)/sqrt(calib(3)^2+calib(1)^2));
% first_angle(1,3) = 0;
% q = angle2quat(first_angle(1,1),first_angle(1,2),first_angle(1,3),'XYZ');
%        
%% For simulates the data flow

for i = 1:t-1
%% triangular methode for integration and quaternion
%     Accelerometer = Acc(i,:)/2 + Acc(i+1,:)/2;   
%     Gyroscope = Gyr(i,:)*(pi/360) + Gyr(i+1,:)*(pi/360);
%     
%% Calculate total Acc magnitude and anjust Beta gain
    acc_mag(i+3,1) = sqrt(Acc(i,1)^2 + Acc(i,2)^2 + Acc(i,3)^2)*0.5 + acc_mag(i+2,1)*0.3 + acc_mag(i+1,1)*0.2;
    if( (acc_mag(i,1)<0.995) || acc_mag(i,1) > 1.005 )
        Beta = 0;   flag(i,1)=0;
    else
        Beta = 0.01; flag(i,1)=1;
    end  
%% calculate quaternion
   % if(norm(Acc(i,:)) == 0), return; end	% handle NaN
    Acc_norm(i,:) = Acc(i,:) / norm(Acc(i,:));	% normalise magnitude

    F = [2*(q(2)*q(4) - q(1)*q(3)) - Acc_norm(i,1)
        2*(q(1)*q(2) + q(3)*q(4)) - Acc_norm(i,2)
        2*(0.5 - q(2)^2 - q(3)^2) - Acc_norm(i,3)];
    J = [-2*q(3),	2*q(4),    -2*q(1),	2*q(2)
        2*q(2),     2*q(1),     2*q(4),	2*q(3)
        0,         -4*q(2),    -4*q(3),	0    ];
    step = (J'*F);
    step = step / norm(step);	% normalise step magnitude

    % Compute rate of change of quaternion
    qDot = 0.5 * quat_prod(q, [0 Gyr(i,1)/180*pi Gyr(i,2)/180*pi Gyr(i,3)/180*pi]) - Beta * step';

    % Integrate to quaternion
    q = q + qDot * t_period;
    quaternion(i,:) = q / norm(q); % normalise quaternion
    q=q / norm(q);
    Acc_rotated(i,:) = quat_rotate(Acc(i,:),quaternion(i,:))*9.81;    
    
    %% Possition calculation
    
    accX(i) =  Acc_rotated(i,1); accY(i) =  Acc_rotated(i,2); accZ(i) =  Acc_rotated(i,3);
    
    
    
    border = [0.3 0.2];

   accX(i)=accX(i)-offsetX;
    speedX = speedX + (t_period)*((accX(i)+accX_old)*0.5); 
    plot_speed_x(i) = speedX;
    tmp= abs(accX(i) - accX_old);                     % zero update control it controls changes 
    if (tmp < border(1,1)) && (abs(accX(i))<border(1,2))             
        counter_zero_updateX = counter_zero_updateX+1;
        zero_updateX = zero_updateX+accX(i);
        if counter_zero_updateX > 30;
            offsetX = offsetX + zero_updateX / 30;            
            speedX=0;
            counter_zero_updateX = 0;
            zero_updateX = 0;            
        end
    else
        counter_offset_updateX = counter_offset_updateX + 1;
        if counter_offset_updateX > 300
            offsetX=0;
            counter_offset_updateX=0;    
        end
        counter_zero_updateX = 0;
        zero_updateX = 0;
    end 
    accX_old = accX(i);
    possitionX = possitionX + (t_period)*(speedX + speedX_old)*0.5;    speedX_old = speedX;
    Position(i,1)=possitionX;
    
    
    
          %%%%%%%%%%%%%%%%%% possitionY %%%%%%%%%%%%%%%%%%%%%
    accY(i)=accY(i)-offsetY;
    speedY = speedY + (t_period)*((accY(i)+accY_old)*0.5);  
    plot_speed_y(i) = speedY;
    tmpY= abs(accY(i) - accY_old);                     % zero update control it controls changes 
    if (tmpY < border(1,1)) && (abs(accY(i))<border(1,2))             
        counter_zero_updateY = counter_zero_updateY+1;
        zero_updateY = zero_updateY+accY(i);
        flag_zero_update(i+1) = flag_zero_update(i);
        if counter_zero_updateY > 30;
            flag_zero_update(i+1) = 1;
            offsetY = offsetY + zero_updateY / 30;            
            speedY=0;
            counter_zero_updateY = 0;
            zero_updateY = 0;            
        end
    else
        flag_zero_update(i+1) = 0;
        counter_offset_updateY = counter_offset_updateY + 1;
        if counter_offset_updateY > 300
            offsetY=0;
            counter_offset_updateY=0;    
        end
        counter_zero_updateY = 0;
        zero_updateY = 0;
    end 
    accY_old = accY(i);
    possitionY = possitionY + (t_period)*(speedY + speedY_old)*0.5;    speedY_old = speedY;
    Position(i,2)=possitionY;
    
           %%%%%%%%%%%%%%%%%% possitionZ %%%%%%%%%%%%%%%%%%%%%
    accZ(i)=accZ(i)-offsetZ;
    speedZ = speedZ + (t_period)*((accZ(i)+accZ_old)*0.5);     
    plot_speed_z(i) = speedZ;
    tmpZ= abs(accZ(i) - accZ_old);                     % zero update control it controls changes 
     if (tmpZ < border(1,1)) && (abs(accZ(i))<border(1,2))          
        counter_zero_updateZ = counter_zero_updateZ+1;
        zero_updateZ = zero_updateZ+accZ(i);
        if counter_zero_updateZ > 30;
            offsetZ = offsetZ + zero_updateZ / 30;            
            speedZ=0;
            counter_zero_updateZ = 0;
            zero_updateZ = 0;            
        end
    else
        counter_offset_updateZ = counter_offset_updateZ + 1;
        if counter_offset_updateZ > 300
            offsetZ=0;
            counter_offset_updateZ=0;    
        end
        counter_zero_updateZ = 0;
        zero_updateZ = 0;
    end 
    accZ_old = accZ(i);
    possitionZ = possitionZ + (t_period)*(speedZ + speedZ_old)*0.5;    speedZ_old = speedZ;
    Position(i,3)=possitionZ;


    
   
end

time=0:t-1;
time = time.' * 0.002;
euler = quat2euler(quaternion)*180/pi;

figure('Name','x de 30 c, y de 40 cm, z de belirsiz bir y�kseklikden sonra 0 a hareket, belirsiz bir a��da');
subplot(3,2,1)
plot(euler)
hold on;
plot(flag);
hold off;
legend('roll','pitch','yaw')
title('Euler angle')
ylabel('degree')


subplot(3,2,2)
plot(quaternion)
title('Quaternion')
legend('w','x','y','z')


subplot(3,1,2)
plot(Acc_rotated)
hold on;
plot(flag_zero_update);
hold off;
axis([0,t,-5,5])
legend('x','y','z','zero update')
title('Rotated and Gravity removed Acc data')
ylabel('m/s/s')


subplot(3,1,3)
plot(Position*100)
legend('x','y','z')
title('Position')
xlabel('milisecond')
ylabel('cm')





