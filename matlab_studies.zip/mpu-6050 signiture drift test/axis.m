%=====================================================
% Written by YAS�N KA�AN TA�KIN
% Date 01.04.2018
%=====================================================
clear all;
close all; 
clc

fileID = fopen('raw_data_14.txt');
raw = textscan(fileID,'%f %f %f %f %f %f %f %f %f %f','Delimiter','\t');
fclose(fileID);
[m,n]= size(raw{1});
t=0.002;

accX=raw{3}*9.81 /16384;
accY=raw{4}*9.81 /16384;
accZ=raw{5}*9.81 /16384;

gyrX=raw{7}/65.5;
gyrY=raw{8}/65.5;
gyrZ=raw{9}/65.5;

aa=0;
for  i = 1:m-1
    aa(i)= sqrt(accX(i)^2 + accY(i)^2 + accZ(i)^2);
end

mean(aa)

subplot(2,1,1)
plot(accX); 
hold on
plot(accY);
hold on
plot(accZ); 
hold on
plot(aa,'g'); 

subplot(2,1,2)
plot(aa)


