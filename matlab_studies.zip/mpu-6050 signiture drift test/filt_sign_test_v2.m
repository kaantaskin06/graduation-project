%=====================================================
% Written by YAS�N KA�AN TA�KIN
% Date 20.03.2018 - 07.04.2018
%=====================================================

clear all;
close all; 
clc
 
SONUC = zeros(24,7);

for  k = 21:44
    %=====================================================
    str = sprintf('raw_data_%d.txt',k);
    %     fid = fopen(str,'wt');    
    fileID = fopen(str);
    raw = textscan(fileID,'%f %f %f %f %f %f %f %f %f %f','Delimiter','\t');
    fclose(fileID);
    [m,n]= size(raw{1});
    t=0.001;

    accX=raw{3};
    accY=raw{4};
    accZ=raw{5};
    tmp =raw{6}/340.00+36.53;
    gyrX=raw{7};
    gyrY=raw{8};
    gyrZ=raw{9};

    acc = [0 0 0 0 0 0 0];
    for i = 1:m
        acc(1) = acc(1) + accX(i);
        acc(2) = acc(2) + accY(i);
        acc(3) = acc(3) + accZ(i);
        acc(4) = acc(4) + tmp(i);
        acc(5) = acc(5) + gyrX(i);
        acc(6) = acc(6) + gyrY(i);
        acc(7) = acc(7) + gyrZ(i);
    end
    SONUC(k,1) = acc(1)/m;
    SONUC(k,2) = acc(2)/m;
    SONUC(k,3) = acc(3)/m;
    SONUC(k,4) = acc(4)/m;
    SONUC(k,5) = acc(5)/m;
    SONUC(k,6) = acc(6)/m;
    SONUC(k,7) = acc(7)/m;
%=====================================================
end 

subplot(2,1,1)
plot(SONUC(:,4))
subplot(2,1,2)
plot(SONUC(:,3))

